#include <iostream>
#include "FileTools.h"
using namespace std;

namespace POLY_TOOLS {

	int main() {
		fs::path test("./test");

		return 0;
	}
}
